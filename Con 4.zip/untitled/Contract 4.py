import pygame

pygame.init()

display_width = 800
display_height = 600

black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
blue = (0, 0, 255)
green = (0, 255, 0)

gameDisplay = pygame.display.set_mode((display_width, display_height))
pygame.display.set_caption('Contract 4')
clock = pygame.time.Clock()

image = pygame.image.load('Sonic.jpg')

def sonic(X, Y):
    gameDisplay.blit(image, (X, Y))
    X = (display_width * 0.45)
    Y = (display_height * 0.8)

running = True

while running == True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False


    sonic(X, Y)
    gameDisplay.fill(white)

    pygame.display.update()
    clock.tick(60)

pygame.quit()
quit()